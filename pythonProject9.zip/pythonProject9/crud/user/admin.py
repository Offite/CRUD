from django.contrib import admin
from .models import Person, Gender

admin.site.register(Person)
